#ifndef CARL_APPAUTOMATED_H
#define CARL_APPAUTOMATED_H


//---------- includes ---------------------------------------------------

//#include <Interface/Application.h>
#include <Image/ImagePointer.h>
#include <../src/CARL/NeuroUnit.h>
#include <../src/CARL/UnitAdministrator.h>
#include <../src/CARL/ConnectivityAdministrator.h>

//---------- class definition -------------------------------------------

class CARL_AppAutomatedStandalone
{

//-----private variables-----//

  private:

    bool runE;

    fca_NeuroUnit* framePointerE;
    fca_NeuroUnit* identityLayerE;

    fca_UnitAdministrator unitAdministratorE;

    fca_ConnectivityAdministrator connectivityAdministratorE;

    int updateDelayE;

    std::string netFileE;
    std::string resultFileE;
    std::string testFileE;


//-----private functions-----//

  private:

    void simulate();



//---------- public functions -------------------------------------------

  public:

    CARL_AppAutomatedStandalone(std::string,std::string,std::string);

    ~CARL_AppAutomatedStandalone();

    void notify();
    void runSimulation();//this is the main script managing the test cycle. Calls simulate and resetSimulation.

    /*    void startSimulation();
    void stopSimulation();
    void resetSimulation();*/

    //    virtual bool init();

    //    virtual bool exit();

    bool isRunning(){return runE;};
};
#endif
