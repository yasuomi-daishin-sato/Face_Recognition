#ifndef CARL_APP_CC
#define CARL_APP_CC


//--------- includes -----------------------------------------------------------------

//#include <Interface/AWLApplication.h>
#include "CARL_AppAutomated.h"
#include "CARL/Frame.h"
#include "CARL/NeuroUnit.h"
#include "CARL/InputLayer.h"
#include "CARL/InputGalleryLayer.h"

//---------- constructors ------------------------------------------------------------

CARL_AppAutomated::CARL_AppAutomated(std::string netFileA,std::string testFileA,std::string resultFileA) :
  //fin_Application(),
unitAdministratorE(),
connectivityAdministratorE()
{
  unitAdministratorE.initUnits(netFileA);

  netFileE = netFileA;
  testFileE = testFileA;
  resultFileE = resultFileA;
  std::cout << "All units built." << std::endl;

  framePointerE = unitAdministratorE.getPointerToUnit("F");

  if(properties()->exist("Update Delay"))
  {
    updateDelayE = properties()->getInt("Update Delay");
  }
  else
  {
    updateDelayE = 1;
  }
  std::cout << "Application initialized successfully." << std::endl;

  runE = false;

  framePointerE->reset();
  std::cout << "now running..." << std::endl;
  // runSimulation();
  std::cout << "now ended..." << std::endl;

};


//---------- destructor -------------------------------------------------------------

CARL_AppAutomated::~CARL_AppAutomated()
{
};

void CARL_AppAutomated::notify()
{std::cout<<"notfied"<<std::endl;
};

void CARL_AppAutomated::runSimulation()
{
  connectivityAdministratorE.releaseConnectivityMap();
  notify();
 std::cout << "runsimulation..." << std::endl;

  fca_InputLayer* inputLayerP = (fca_InputLayer*)unitAdministratorE.getPointerToUnit("0");
  identityLayerE = unitAdministratorE.getPointerToUnit("5");
  fca_NeuroUnit* galleryLayerP = unitAdministratorE.getPointerToUnit("7");

  uint landmarksL = identityLayerE->getNumberOfSubUnits();
  std::vector<fca_NeuroUnit*> identityMacrocolumnsL = identityLayerE->getSubUnits();

  uint facesL = (identityMacrocolumnsL[0])->getNumberOfSubUnits();
  std::cerr<<landmarksL<<" landmarks with "<< facesL <<" faces "<<std::endl;
  std::vector<std::vector<fca_NeuroUnit*> > identityMinicolumnsL(landmarksL);
  std::vector<std::vector<double*> > identityMinicolumnsActivitiesL(landmarksL);
  std::vector<double*> dummyVectorL;
  for (uint i=0;i<landmarksL;i++)
  {
    identityMinicolumnsL[i]=((identityMacrocolumnsL[i])->getSubUnits());
    dummyVectorL.clear();
    for (uint j=0;j<facesL;j++)
      { dummyVectorL.push_back((identityMinicolumnsL[i][j])->getPointerToActivity());}
    identityMinicolumnsActivitiesL[i]=dummyVectorL;
  }

  double sumL=0;//overall activity;
  double dummyMaxL,dummyL;
  std::vector<double> identityActivitiesL(facesL);
  std::map<double,uint> activityMapL;
  std::vector<uint> maxAtLandmarkL(landmarksL);
  std::vector<uint> maxPerFaceL(facesL);

  std::ifstream testfileL(testFileE.c_str());
  uint numberL = 0;//image number


  std::ofstream resultfileL(resultFileE.c_str());
  resultfileL << "Tested images in ";
  //  std::cout<<" and gallery "<<((fca_InputGalleryLayer*)galleryLayerP)->getGalleryFile()<<std::endl;
  resultfileL<< testFileE <<" using network "<<netFileE<<" and gallery "<<((fca_InputGalleryLayer*)galleryLayerP)->getGalleryFile()<<std::endl;
  resultfileL << facesL<< " images with "<< landmarksL <<" landmarks."<<std::endl;
  std::string imageL;
  
  resultfileL.close();

  while (testfileL.good()) {
    resultfileL.open(resultFileE.c_str(),std::ios::app);
    imageL.clear();
    testfileL >> imageL;
    // std::cout << stringL << std::endl;
    if (imageL.size()!=0)  {
      unitAdministratorE.changeProperty(inputLayerP,"InputLayer","Image", imageL, true);
      std::cout<<"testing image No. "<<numberL<<" = "<<imageL<<std::endl;
      resultfileL<<"Image "<<numberL<<" : Identity ";
      simulate();//resetting should not be necessary since image has changed
      //      std::cout << imageL<<"finished.\n";
      sumL = 0;
      for (uint j=0;j<facesL;j++)
      {
	identityActivitiesL[j]=0;
	maxPerFaceL[j] = 0;
      }
      for (uint i=0;i<landmarksL;i++)
      {
	dummyMaxL = 0;
	
	for (uint j=0;j<facesL;j++)
	{
	  dummyL= *(identityMinicolumnsActivitiesL[i][j]);
	  sumL += dummyL;//sum up all activities
	  identityActivitiesL[j] += dummyL;//sum up activities in bins according to faces
	  if (dummyL>dummyMaxL)
	  {
	    dummyMaxL = dummyL;
	    maxAtLandmarkL[i]=j;
	    
	  }  	    
	}
	maxPerFaceL[maxAtLandmarkL[i]] += 1;
      }     
      //now evaluate activities
      activityMapL.clear();
      double maxL=0;
      uint indexMaxL = 0;
      for (uint j=0;j<facesL;j++)
      {
	activityMapL.insert(std::pair<double,int>(identityActivitiesL[j],j));
	if (maxL < identityActivitiesL[j])
	{
	  maxL = identityActivitiesL[j];
	  indexMaxL = j;
	  }
      }
      std::map<double,uint>::reverse_iterator iterL = activityMapL.rbegin();
      if (iterL->first != identityActivitiesL[indexMaxL])
	std::cout<<"Highest map entry "<<iterL->first<<" and highest directly found value "<<identityActivitiesL[indexMaxL]<<" are not the same!!"<<std::endl;
 
      std::cout <<indexMaxL << " has according to identityActivities "<<(identityActivitiesL[indexMaxL])/sumL <<" of overall activity and "<< maxPerFaceL[indexMaxL]<< " of all maxima.\n"<<std::endl;
        resultfileL << iterL->second<< " has "<<(iterL->first)/sumL <<" of overall activity and "<< maxPerFaceL[iterL->second]<< " of all maxima. Following:";
      for (uint j=0;j<30;j++)//set here the highest rank you want to consider
      {
	iterL++;
	resultfileL <<" " <<iterL->second;
      }
      resultfileL <<std::endl;
      
    }
    ++numberL ;
    resultfileL.close();
  }
  std::cout <<"CARL_Automated has finished. "<<numberL<<" images were tested.\n Results have been written to "<<resultFileE<<std::endl;
  testfileL.close();
  //  resultfileL.close();

  
};

void CARL_AppAutomated::simulate()
{
  runE = true;


  int cycleL = 0;
  int iterationsL = 0;
  /*  identityLayerE->setNuClockParameters("linearIncrease,.0,.45,20");
  while(runE)
  {
    ((fca_Frame*)framePointerE)->compute();
     ++cycleL;
    ++iterationsL;
    //    if (fca_Frame::timeG > 20.1)//set here desired stopping time
    if (fca_Frame::timeG > 19.7)//set here desired stopping time
      {runE = false;}
  }
  identityLayerE->setNuClockParameters("linearIncrease,.1,1,20");
  runE = true;*/
  while(runE)
  {
    ((fca_Frame*)framePointerE)->compute();
     ++cycleL;
    ++iterationsL;
    if (fca_Frame::timeG > 16)//set here desired stopping time
      {runE = false;}
  }

};

void CARL_AppAutomated::startSimulation()
{
  if(!runE)
  {
    properties()->changeProperty("Reset", "0");
    runSimulation();
  }
};

void CARL_AppAutomated::stopSimulation()
{
  if(runE)
  {
    runE = false;
    //   notify();
  }
};

void CARL_AppAutomated::resetSimulation()
{
  stopSimulation();
  framePointerE->reset();
  //  notify();
};


bool CARL_AppAutomated::init()
{
  return true;
};

bool CARL_AppAutomated::exit()
{
  return true;
};

#endif
