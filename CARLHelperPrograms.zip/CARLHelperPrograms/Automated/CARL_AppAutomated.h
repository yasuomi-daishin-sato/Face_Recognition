#ifndef CARL_APPAUTOMATED_H
#define CARL_APPAUTOMATED_H


//---------- includes ---------------------------------------------------

#include <Interface/Application.h>
#include <Image/ImagePointer.h>
#include <CARL/NeuroUnit.h>
#include <CARL/UnitAdministrator.h>
#include <CARL/ConnectivityAdministrator.h>

//---------- class definition -------------------------------------------

class CARL_AppAutomated : public fin_Application
{

//-----private variables-----//

  private:

    bool runE;

    fca_NeuroUnit* framePointerE;
    fca_NeuroUnit* identityLayerE;

    fca_UnitAdministrator unitAdministratorE;

    fca_ConnectivityAdministrator connectivityAdministratorE;

    int updateDelayE;

    std::string netFileE;
    std::string resultFileE;
    std::string testFileE;


//-----private functions-----//

  private:

    void simulate();



//---------- public functions -------------------------------------------

  public:

    CARL_AppAutomated(std::string,std::string,std::string);

    ~CARL_AppAutomated();

    void notify();
    void runSimulation();//this is the main script managing the test cycle. Calls simulate and resetSimulation.

    void startSimulation();
    void stopSimulation();
    void resetSimulation();

    virtual bool init();

    virtual bool exit();

    bool isRunning(){return runE;};
};
#endif
