//#include <Interface/AWLApplication.h>
#include <Interface/Application.h>
#include <Interface/MainWindow.h>
//#include <Interface/MainWindowOutputStreamBuffer.h>
#include </usr/include/unistd.h>

#include "CARL_AppAutomated.h"
//#include "CARL_GUIAutomated.h"

#include "../src/CARL/Minicolumn.h"


int main(int argc, char** argv)
{
  /*
  float* a;
  a=new float;
  //a[1]=new float;
  std::cout<<"Size of float is "<<sizeof(float)<<" and of float pointer"<<(sizeof a)<<std::endl;
  double* b[100];
  b[0]=new double;
  std::cout<<"Size of double is "<<sizeof(double)<<" and of 100 double pointers "<<(sizeof b)<<std::endl;
  std::cout << "Initialisation started." << std::endl;

  fca_Minicolumn* mcP;
  mcP = new fca_Minicolumn();
  std::cout<<"Size of Minicolumn pointer is "<<(sizeof mcP)<<std::endl;
  */

  //setting the basic name of the parameter files
  std::string basicFileNameL = "XML/default";
  std::string testFileNameL = "AutomatedTesting/testfile";
  std::string resultFileNameL = "AutomatedTesting/resultfile";
  if (argc <=3)
  {
    std::cout<<"Syntax: CARL_Automated net-file testfile resultfile"<<std::endl;
  }
  else
  {
    basicFileNameL = argv[1];
    testFileNameL = argv[2];
    resultFileNameL = argv[3];

  //getting the path of the working directory
  char workingDirL[128];
  getwd(workingDirL);

  //constructing the full basic path of the parameter files
  std::string fullBasicFileNameL;
  fullBasicFileNameL.append(workingDirL);
  fullBasicFileNameL.append("/");
  fullBasicFileNameL.append(basicFileNameL);
  std::cout << "I will use this basic path: " <<  fullBasicFileNameL << std::endl;

  //load the XML-file to a singleton object
  //  fut_Properties::instance()->loadXMLFile(fullBasicFileNameL + ".xml");

  //initialise the basic AWL application
  //  fin_AWLApplication appL(argc, argv);

  //a main window, mainly used for text messages
  //MainWindowPointer mainWindowL(new fin_MainWindow("Main Window", "I am the main window!", 0, 710, 300, 250));
  std::cout << "now starting application" << std::endl;

  //here our CARL application is instantiated
  CARL_AppAutomated applicationL(fullBasicFileNameL + ".net", testFileNameL, resultFileNameL);
  fin_Application::setInstance(&applicationL);

  //and here comes our window controller which sets the GUI
  //  CARL_GUIAutomated_Pointer windowControllerL(new CARL_GUIAutomated(mainWindowL.pointer()));
  //CARL_GUIAutomated_Pointer windowControllerL(new CARL_GUIAutomated());
  //  fin_Application::instance()->windowController(windowControllerL.pointer());
  applicationL.runSimulation();

std::cout << "Everything finished"<< std::endl;


//  return appL.exec();
  }
};
