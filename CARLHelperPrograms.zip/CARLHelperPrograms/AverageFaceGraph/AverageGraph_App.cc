#ifndef AVERAGEGRAPH_APP_CC
#define AVERAGEGRAPH_APP_CC


//--------- includes -----------------------------------------------------------------

#include <Interface/AWLApplication.h>
#include "AverageGraph_App.h"
#include <LinearAlgebra/Eigen.h>

#include <fstream>
#include <set>

//---------- constructors ------------------------------------------------------------

AverageGraph_App::AverageGraph_App() :
fin_Application()
{
  init();
};


//---------- destructors -------------------------------------------------------------

AverageGraph_App::~AverageGraph_App()
{
};

bool AverageGraph_App::loadImage(std::string nameA)
{
  if(!imagePointerE.empty())
  {
    fim_ImagePointer tmpImageL;

    tmpImageL.copyRep(imagePointerE);

  if ((nameA.find(".jp") != std::string::npos)||(nameA.find(".JP") != std::string::npos))
  	imagePointerE.readJPEG(nameA.c_str());
  else if ((nameA.find(".tif") != std::string::npos)||(nameA.find(".TIF") != std::string::npos))
  	imagePointerE.readTIFF(nameA.c_str());
  else if ((nameA.find(".png") != std::string::npos)||(nameA.find(".PNG") != std::string::npos))
  	imagePointerE.readPNG(nameA.c_str());
  else
    {
    std::cout<<"image format not recognized! only use jpg, tiff, or png!\n Loading default face"<<std::endl;
    imagePointerE.readTIFF("/home/fias/wolfrum/C++/AverageFaceGraph/me.tiff");
    //return false;
    
    }


  /*  if(imagePointerE.readTIFF(nameA.c_str()) != 0)
    {
      imagePointerE.copyRep(tmpImageL);
      return false;
      }*/
  }
  else
  {
  if ((nameA.find(".jp") != std::string::npos)||(nameA.find(".JP") != std::string::npos))
  	imagePointerE.readJPEG(nameA.c_str());
  else if ((nameA.find(".tif") != std::string::npos)||(nameA.find(".TIF") != std::string::npos))
  	imagePointerE.readTIFF(nameA.c_str());
  else if ((nameA.find(".png") != std::string::npos)||(nameA.find(".PNG") != std::string::npos))
  	imagePointerE.readPNG(nameA.c_str());
  else
    {
    std::cout<<"image format not recognized! only use jpg, tiff, or png!\n Loading defaul face"<<std::endl;
    imagePointerE.readTIFF("/home/fias/wolfrum/C++/AverageFaceGraph/me.tiff");
    //return false;
    
    }
  /*  if(imagePointerE.readTIFF(nameA.c_str()) != 0)
    {
      return false;
      }*/
  }

  imageFileNameE = nameA;
  return true;
};

bool AverageGraph_App::saveGraph(std::string nameA)
{
  std::ofstream fileL(nameA.c_str());
  int imageSizeXL = imagePointerE->xResolution();
  int imageSizeYL = imagePointerE->yResolution();

  /*
  fileL << "!!!Do not change this file unless you know what can go wrong!!!" << std::endl << std::endl;

  fileL << "Image: " << imageFileNameE << std::endl;
  fileL << "Width: " << imageSizeXL << std::endl;
  fileL << "Height: " << imageSizeYL << std::endl << std::endl;

  fileL << "Nodes: " << listOfNodesE.size() << std::endl << std::endl;

  for(uint i = 0; i < listOfNodesE.size(); ++i)
  {
    fileL << "Node " << i << ": " << (uint)(listOfNodesE[i].x * imageSizeXL) << ", " << (uint)(listOfNodesE[i].y *imageSizeYL) << std::endl;
  }

  fileL << std::endl << "Connections: " << listOfConnectionsE.size() << std::endl << std::endl;

  for(uint i = 0; i < listOfConnectionsE.size(); ++i)
  {
    fileL << "Connection " << i << ": " << listOfConnectionsE[i].connectorA << ", " << listOfConnectionsE[i].connectorB << std::endl;
  }
  */

  fileL << "image       = '" << imageFileNameE << "'"<< std::endl;
  fileL << "remark: this image is just a place keeper and provides image size. For compatibility with CARL, meaningless for an average graph."<< std::endl;

  fileL << "graphtype   = free" << std::endl;
  fileL << "nodes       = " << averageGraphE.node.size() << std::endl;
  fileL << "edges       = " << averageGraphE.connection.size() << std::endl;
  fileL << "range       = [0," << imageSizeXL << ",0," << imageSizeYL << "]\n\n\n";

  fileL << "trafotype                      = GaborTrafo\n";
  fileL << "number of levels               = 5\n";
  fileL << "number of directions           = 8\n";
  fileL << "maximum                        = 1.5708\n";
  fileL << "factor                         = 0.707107\n";
  fileL << "sigma                          = 6.28319\n";
  fileL << "DC free                        = true\n";
  fileL << "space accuracy                 = 2\n\n";

  fileL << std::endl;
  
  fileL << "Calculated from " << numberOfGraphs() <<" graphs\n";

  for(uint i = 0; i < averageGraphE.node.size(); ++i)
  {
    fileL << "point " << i << " = [" << (averageGraphE.node[i].x * imageSizeXL) << "," << (averageGraphE.node[i].y *imageSizeYL) << "],   index =" << i << std::endl;
  }
  
  fileL << std::endl;
  fileL << "Principal Components:"<<std::endl;

  for(uint i = 0; i < averageGraphE.node.size(); ++i)
  {
    fileL << "PC1 " << i << " = [" << (averageGraphE.node[i].PC1[0] * imageSizeXL) << "," << (averageGraphE.node[i].PC1[1] *imageSizeYL) << "],   index =" << i << std::endl;
    fileL << "PC1length " << i << " = ["<< averageGraphE.node[i].PC1length  << "],   index =" << i << std::endl;
    fileL << "PC2 " << i << " = [" << (averageGraphE.node[i].PC2[0] * imageSizeXL) << "," << (averageGraphE.node[i].PC2[1] *imageSizeYL) << "],   index =" << i << std::endl;
    fileL << "PC2length " << i << " = ["<< averageGraphE.node[i].PC2length  << "],   index =" << i << std::endl; 
   }
 
  fileL << std::endl;

  for(uint i = 0; i < averageGraphE.node.size(); ++i)
  {
    fileL << "feast " << i << " =\n";
  }

  fileL << std::endl;

  for(uint i = 0; i < averageGraphE.connection.size(); ++i)
  {
    fileL << "edge " << i << " = [" << averageGraphE.connection[i].connectorA << ", " <<  averageGraphE.connection[i].connectorB << "]\n";
  }
  
	fileL << std::endl;
  fileL << "Principal Components"<<std::endl; 
  for(uint i = 0; i < averageGraphE.connection.size(); ++i)
  {
    fileL << "average " << i << " = [" << (averageGraphE.connection[i].x * imageSizeXL) << "," << (averageGraphE.connection[i].y *imageSizeYL) << "],   index =" << i << std::endl;
    fileL << "PC1 " << i << " = [" << (averageGraphE.connection[i].PC1[0] * imageSizeXL) << "," << (averageGraphE.connection[i].PC1[1] *imageSizeYL) << "],   index =" << i << std::endl;
    fileL << "PC1length " << i << " = ["<< averageGraphE.connection[i].PC1length  << "],   index =" << i << std::endl;
    fileL << "PC2 " << i << " = [" << (averageGraphE.connection[i].PC2[0] * imageSizeXL) << "," << (averageGraphE.connection[i].PC2[1] *imageSizeYL) << "],   index =" << i << std::endl;
    fileL << "PC2length " << i << " = ["<< averageGraphE.connection[i].PC2length  << "],   index =" << i << std::endl; 
   }

  fileL.close();
  return true;
};

void AverageGraph_App::clear()
{
	graphsE.clear();
	currentGraphE.node.clear();
	currentGraphE.connection.clear();
	averageGraphE.node.clear();
	averageGraphE.connection.clear();
	
};

bool AverageGraph_App::loadGraph(std::string nameA)
{
	std::cout<<"Loading file "<<nameA<<std::endl;
/*
  std::ifstream fileL(nameA.c_str());
  std::string tmpStringL;
  uint tmpUintL;
  std::string fileNameL;
  uint numberOfNodesL;
  double xCoordL, yCoordL;
  Node nodeL;
  std::vector<Node> listOfNodesL;
  uint numberOfConnectionsL;
  int connectorAL, connectorBL;
  Connection connectionL;
  std::vector<Connection> listOfConnectionsL;

  getline(fileL, tmpStringL);
  fileL >> tmpStringL;
  if(tmpStringL == "Image:")
  {
    fileL >> fileNameL;
  }
  else
  {
    fileL.close();
    return false;
  }

  fileL >> tmpStringL;
  if(tmpStringL == "Width:")
  {
    fileL >> tmpUintL;
  }
  else
  {
    fileL.close();
    return false;
  }
  double imageSizeXL = (double)(tmpUintL);

  fileL >> tmpStringL;
  if(tmpStringL == "Height:")
  {
    fileL >> tmpUintL;
  }
  else
  {
    fileL.close();
    return false;
  }
  double imageSizeYL = (double)(tmpUintL);

  fileL >> tmpStringL;
  if(tmpStringL == "Nodes:")
  {
    fileL >> numberOfNodesL;
  }
  else
  {
    fileL.close();
    return false;
  }

  for(uint i = 0; i < numberOfNodesL; ++i)
  {
    fileL >> tmpStringL;
    if(tmpStringL != "Node")
    {
      fileL.close();
      return false;
    }
    fileL >> tmpUintL;
    if(tmpUintL != i)
    {
      fileL.close();
      return false;
    }
    fileL >> tmpStringL;
    if(tmpStringL != ":")
    {
      fileL.close();
      return false;
    }
    fileL >> xCoordL;

    fileL >> tmpStringL;
    if(tmpStringL != ",")
    {
      fileL.close();
      return false;
    }
    fileL >> yCoordL;

    nodeL.x = xCoordL/imageSizeXL;
    nodeL.y = yCoordL/imageSizeYL;
    listOfNodesL.push_back(nodeL);
  }

  fileL >> tmpStringL;
  if(tmpStringL == "Connections:")
  {
    fileL >> numberOfConnectionsL;
  }
  else
  {
    fileL.close();
    return false;
  }

  for(uint i = 0; i < numberOfConnectionsL; ++i)
  {
    fileL >> tmpStringL;
    if(tmpStringL != "Connection")
    {
      fileL.close();
      return false;
    }
    fileL >> tmpUintL;
    if(tmpUintL != i)
    {
      fileL.close();
      return false;
    }
    fileL >> tmpStringL;
    if(tmpStringL != ":")
    {
      fileL.close();
      return false;
    }
    fileL >> connectorAL;
    fileL >> tmpStringL;
    if(tmpStringL != ",")
    {
      fileL.close();
      return false;
    }
    fileL >> connectorBL;

    connectionL.connectorA = connectorAL;
    connectionL.connectorB = connectorBL;
    listOfConnectionsL.push_back(connectionL);
  }

  fileL.close();
*/

  std::ifstream fileL(nameA.c_str());
  std::string tmpStringL;
  std::string fileNameL;
  uint tmpUintL;
  uint numberOfNodesL;
  double xCoordL, yCoordL, imageSizeXL, imageSizeYL;
  uint numberOfConnectionsL;
  int connectorAL, connectorBL;
  uint posL;
  Node nodeL;
  std::vector<Node> listOfNodesL;
  Connection connectionL;
  std::vector<Connection> listOfConnectionsL;

  fileFind(fileL, "image");
  fileL >> tmpStringL;
  fileL >> tmpStringL;
  fileNameL = tmpStringL.substr(1, tmpStringL.size() - 2);

  fileFind(fileL, "nodes");
  fileL >> tmpStringL;
  fileL >> numberOfNodesL;

  fileFind(fileL, "edges");
  fileL >> tmpStringL;
  fileL >> numberOfConnectionsL;

  fileFind(fileL, "range");
  fileL >> tmpStringL;
  fileL >> tmpStringL;
  posL = tmpStringL.find(",");
  tmpStringL = tmpStringL.erase(0, posL + 1);
  posL = tmpStringL.find(",");
  imageSizeXL = atof((tmpStringL.substr(0, posL)).c_str());
  tmpStringL = tmpStringL.erase(0, posL + 1);
  posL = tmpStringL.find(",");
  tmpStringL = tmpStringL.erase(0, posL + 1);
  imageSizeYL = atof((tmpStringL.substr(0, tmpStringL.size() - 1)).c_str());

	Node CoML;//center of mass
	CoML.x = 0;
	CoML.y = 0;	
  for(uint i = 0; i < numberOfNodesL; ++i)
  {
    fileFind(fileL, "point");
    fileL >> tmpUintL;
    if(tmpUintL == i)
    {
      fileL >> tmpStringL;
      fileL >> tmpStringL;

      posL = tmpStringL.find(",");
      xCoordL = atof((tmpStringL.substr(1, posL - 1)).c_str());
      yCoordL = atof((tmpStringL.substr(posL + 1, tmpStringL.length() - posL - 3)).c_str());

      nodeL.x = xCoordL/imageSizeXL;
      CoML.x += nodeL.x;
      nodeL.y = yCoordL/imageSizeYL;
      CoML.y += nodeL.y;
      nodeL.PC1length = 0;
      nodeL.PC2length = 0;          
      listOfNodesL.push_back(nodeL);
    }
  }
  CoML.x /= numberOfNodesL; 
  CoML.x -= .5;//to center it around 0
  CoML.y /= numberOfNodesL; 	
  CoML.y -= .5;//to center it around 0	
  
  fileL >> tmpStringL;
  fileL >> tmpStringL;

  tmpStringL="";
  while (tmpStringL == "")
     fileL >> tmpStringL;
  
  bool flagPCL=false;
  if (tmpStringL.find("Principal") != std::string::npos)//PC info exists
  {
    flagPCL=true;
    std::cout<<"loading an average graph, do not try to combine it with other graphs!!"<<std::endl;
    for(uint i = 0; i < numberOfNodesL; ++i)
    { 
      fileFind(fileL, "PC1");
	fileL >> tmpUintL;
	if(tmpUintL == i)
	  {
	    fileL >> tmpStringL;
	    fileL >> tmpStringL;    
	    posL = tmpStringL.find(",");
	    xCoordL = atof((tmpStringL.substr(1, posL - 1)).c_str());
	    yCoordL = atof((tmpStringL.substr(posL + 1, tmpStringL.length() - posL - 3)).c_str());
	    listOfNodesL[i].PC1[0] = xCoordL/imageSizeXL;
	    listOfNodesL[i].PC1[1] = yCoordL/imageSizeYL;
	    fileFind(fileL, "PC1length");
	    fileL >> tmpUintL;
	    fileL >> tmpStringL;
	    fileL >> tmpStringL;
	    xCoordL = atof((tmpStringL.substr(1, tmpStringL.length() - posL - 3)).c_str());
	    listOfNodesL[i].PC1length = xCoordL;


	    fileFind(fileL, "PC2");
	    fileL >> tmpUintL;
	    fileL >> tmpStringL;
	    fileL >> tmpStringL;    
	    posL = tmpStringL.find(",");
	    xCoordL = atof((tmpStringL.substr(1, posL - 1)).c_str());
	    yCoordL = atof((tmpStringL.substr(posL + 1, tmpStringL.length() - posL - 3)).c_str());
	    listOfNodesL[i].PC2[0] = xCoordL/imageSizeXL;
	    listOfNodesL[i].PC2[1] = yCoordL/imageSizeYL;
	    fileFind(fileL, "PC2length");
	    fileL >> tmpUintL;
	    fileL >> tmpStringL;
	    fileL >> tmpStringL;
	    xCoordL = atof((tmpStringL.substr(1, tmpStringL.length() - posL - 3)).c_str());
	    listOfNodesL[i].PC2length = xCoordL;
	  }
    } 
  }
  else std::cout<<"loading m average graph:"<<tmpStringL<<std::endl;
  
	
  for(uint i = 0; i < numberOfConnectionsL; ++i)
  {
    fileFind(fileL, "edge");
    fileL >> tmpUintL;
    if(tmpUintL == i)
    {
      fileL >> tmpStringL;
      fileL >> tmpStringL;
      connectorAL = (int)atof((tmpStringL.substr(1, tmpStringL.size() - 2)).c_str());

      fileL >> tmpStringL;
      connectorBL = (int)atof((tmpStringL.substr(0, tmpStringL.size() - 1)).c_str());

      connectionL.connectorA = connectorAL;
      connectionL.connectorB = connectorBL;
      connectionL.x = listOfNodesL[connectorBL].x - listOfNodesL[connectorAL].x;
      connectionL.y = listOfNodesL[connectorBL].y - listOfNodesL[connectorAL].y;
      connectionL.PC1length = 0;
      connectionL.PC2length = 0;      
      listOfConnectionsL.push_back(connectionL);
     // std::cout<<connectorBL<<" "<<listOfNodesL[connectorBL].x<<" and "<<connectorAL<<":"<<listOfNodesL[connectorAL].x<<std::endl;
       
    }
  }

  if (flagPCL)//now get edge PC info
    for(uint i = 0; i < numberOfConnectionsL; ++i)
    {
      fileFind(fileL, "PC1");
      fileL >> tmpUintL;
      if(tmpUintL == i)
	{
	  fileL >> tmpStringL;
	  fileL >> tmpStringL;    
	  posL = tmpStringL.find(",");
	  xCoordL = atof((tmpStringL.substr(1, posL - 1)).c_str());
	  yCoordL = atof((tmpStringL.substr(posL + 1, tmpStringL.length() - posL - 3)).c_str());
	  listOfConnectionsL[i].PC1[0] = xCoordL/imageSizeXL;
	  listOfConnectionsL[i].PC1[1] = yCoordL/imageSizeYL;
	  fileFind(fileL, "PC1length");
	  fileL >> tmpUintL;
	  fileL >> tmpStringL;
	  fileL >> tmpStringL;
	  xCoordL = atof((tmpStringL.substr(1, tmpStringL.length() - posL - 3)).c_str());
	  listOfConnectionsL[i].PC1length = xCoordL;
	  
	  fileFind(fileL, "PC2");
	  fileL >> tmpUintL;
	  fileL >> tmpStringL;
	  fileL >> tmpStringL;    
	  posL = tmpStringL.find(",");
	  xCoordL = atof((tmpStringL.substr(1, posL - 1)).c_str());
	  yCoordL = atof((tmpStringL.substr(posL + 1, tmpStringL.length() - posL - 3)).c_str());
	  listOfConnectionsL[i].PC2[0] = xCoordL/imageSizeXL;
	  listOfConnectionsL[i].PC2[1] = yCoordL/imageSizeYL;
	  fileFind(fileL, "PC2length");
	  fileL >> tmpUintL;
	  fileL >> tmpStringL;
	  fileL >> tmpStringL;
	  xCoordL = atof((tmpStringL.substr(1, tmpStringL.length() - posL - 3)).c_str());
	  listOfConnectionsL[i].PC2length = xCoordL;
	}
    } 
  
  fileL.close();

    

  if(!loadImage(fileNameL))
  {
    return false;
  }
  if (currentGraphE.node.size()>0)//if not, we don't have a graph yet
    {
      graphsE.push_back(currentGraphE);//put old graph into graph list
    }
	
  currentGraphE.CoM = CoML;
  std::cout<<"COM x:"<<currentGraphE.CoM.x<<" COM y: "<<currentGraphE.CoM.y<<std::endl;
  currentGraphE.node = listOfNodesL;
  currentGraphE.connection = listOfConnectionsL;
  calculateAverage();

  if (flagPCL)
  {
    averageGraphE=currentGraphE;
  }


	
  return true;
};

bool AverageGraph_App::calculateAverage()
{
	averageGraphE.node.clear();

	bool errorL = true;
	if (averageGraphE.connection.size() > 0)//average Graph has been set at least once before: check for consistency
	{
		errorL = false;
		for (uint connL=0; connL<averageGraphE.connection.size(); ++connL)
		{
			if ((averageGraphE.connection[connL].connectorA != currentGraphE.connection[connL].connectorA)||(averageGraphE.connection[connL].connectorB != currentGraphE.connection[connL].connectorB))
				errorL = true;
		}
		if (errorL)
		{
			std::cout<<"WARNING: Graph Topologies are inconsistent!\n Only nodes, but not connectivity, of the resulting average graph will be useful!"<<std::endl;
		}		
	}
	
	if (errorL)//means here that connections have to be copied for any of two possibel reasons
	{
		averageGraphE.connection.clear();
		for (uint connL=0; connL<currentGraphE.connection.size(); ++connL)
		{
			averageGraphE.connection.push_back(currentGraphE.connection[connL]);
		}
	}
	
	//find variance of landmarks
	uint numberL = graphsE.size() + 1;//because current graph is not in this vector
	double xL,yL,meanXL,meanYL,S11L,S12L,S22L;//Sxx stands for the scatter matrix
	fla_RealMatrix SL(2,2);
	double eigen1L,eigen2L;

	for (uint pointL=0;pointL<currentGraphE.node.size(); ++pointL)
	{
		meanXL = 0;		
		meanYL = 0;				
		S11L = 0;				
		S12L = 0;						
		S22L = 0;		
						
		for (uint graphL=0;graphL<(numberL-1);++graphL)
		{	
			xL = graphsE[graphL].node[pointL].x - graphsE[graphL].CoM.x;// in order to allow the single graphs to have different locations in the image
			yL = graphsE[graphL].node[pointL].y - graphsE[graphL].CoM.y;
			meanXL +=xL;
			meanYL += yL;
			S11L += xL * xL;
			S12L += xL * yL;
			S22L += yL * yL;
		}
		xL =currentGraphE.node[pointL].x - currentGraphE.CoM.x;
		yL =currentGraphE.node[pointL].y - currentGraphE.CoM.y;
		meanXL +=xL;
		meanYL += yL;
		S11L += xL * xL;
		S12L += xL * yL;
		S22L += yL * yL;
		
		meanXL /= numberL;
		meanYL /= numberL;		
		S11L = S11L/numberL - meanXL*meanXL;
		S12L = S12L/numberL - meanXL*meanYL;
		S22L = S22L/numberL - meanYL*meanYL;
		SL(0,0)=S11L;
		SL(0,1)=S12L;
		SL(1,0)=S12L;
		SL(1,1)=S22L;
		fla_Eigen eigenL(SL);
		fla_ComplexMatrix eigenVecL(2,2);
		eigenL.rightEigenVectors(eigenVecL);
		fla_ComplexVector dummyL;
		eigenL.eigenValues(dummyL);
		eigen1L = sqrt(abs(dummyL(0).real()));//sqrt gives us the std of distribution
		eigen2L = sqrt(abs(dummyL(1).real()));
	
		Node nodeL;
		nodeL.x = meanXL;
		nodeL.y = meanYL;
		if (abs(eigen1L) > abs(eigen2L))//take EVec1 as first PC. Scale with sqrt(EV).
		{
			dummyL = fla_matrixToVector(eigenVecL,0);
			nodeL.PC1[0] = dummyL(0).real();
			nodeL.PC1[1] = dummyL(1).real();
			dummyL = fla_matrixToVector(eigenVecL,1);
			nodeL.PC2[0] = dummyL(0).real();
			nodeL.PC2[1] = dummyL(1).real();
			nodeL.PC1[0] *= eigen1L;
			nodeL.PC1[1] *= eigen1L;
			nodeL.PC1length = eigen1L;
			nodeL.PC2[0] *= eigen2L;
			nodeL.PC2[1] *= eigen2L;
			nodeL.PC2length = eigen2L;
		}
		else
		{
			dummyL = fla_matrixToVector(eigenVecL,1);
			nodeL.PC1[0] = dummyL(0).real();
			nodeL.PC1[1] = dummyL(1).real();
			dummyL = fla_matrixToVector(eigenVecL,0);
			nodeL.PC2[0] = dummyL(0).real();
			nodeL.PC2[1] = dummyL(1).real();
			nodeL.PC1[0] *= eigen2L;
			nodeL.PC1[1] *= eigen2L;
			nodeL.PC1length = eigen2L;
			nodeL.PC2[0] *= eigen1L;
			nodeL.PC2[1] *= eigen1L;
			nodeL.PC2length = eigen1L;
		}		
//		std::cout<<"here3"<<std::endl;	
		averageGraphE.node.push_back(nodeL);
//	  std::cout<<pointL<<": x:"<<xL<< " meanX: "<<meanXL<<" y:"<<yL<< " meanY: "<<meanYL<<" eigen1: "<<eigen1L<<", eigen2: "<<eigen2L<<",\n PC1:"<<averageGraphE.node[pointL].PC1[0]<<","<<averageGraphE.node[pointL].PC1[1]<<", PC2:"<<averageGraphE.node[pointL].PC2[0]<<","<<averageGraphE.node[pointL].PC2[1]<<std::endl;		
	  if (eigen1L !=eigen1L)
	  	std::cout<<"NaN!!"<<std::endl;
	  if (std::isnan(eigen1L))
	  	std::cout<<"NaN2!!"<<std::endl;	  
	}
	
	//find variance of edges
//	std::cout<<numberL<<std::endl;
	for (uint edgeL=0;edgeL<currentGraphE.connection.size(); ++edgeL)
	{
		meanXL = 0;		
		meanYL = 0;				
		S11L = 0;				
		S12L = 0;						
		S22L = 0;		
						
		for (uint graphL=0;graphL<(numberL-1);++graphL)
		{	
			xL = graphsE[graphL].connection[edgeL].x;
			yL = graphsE[graphL].connection[edgeL].y;
			meanXL +=xL;
			meanYL += yL;
			S11L += xL * xL;
			S12L += xL * yL;
			S22L += yL * yL;
		}
		xL =currentGraphE.connection[edgeL].x;
		yL =currentGraphE.connection[edgeL].y;
		meanXL +=xL;
		meanYL += yL;
		S11L += xL * xL;
		S12L += xL * yL;
		S22L += yL * yL;
		
		meanXL /= numberL;
		meanYL /= numberL;		
		S11L = S11L/numberL - meanXL*meanXL;
		S12L = S12L/numberL - meanXL*meanYL;
		S22L = S22L/numberL - meanYL*meanYL;
		SL(0,0)=S11L;
		SL(0,1)=S12L;
		SL(1,0)=S12L;
		SL(1,1)=S22L;
		fla_Eigen eigenL(SL);
		fla_ComplexMatrix eigenVecL(2,2);
		eigenL.rightEigenVectors(eigenVecL);
		fla_ComplexVector dummyL;
		eigenL.eigenValues(dummyL);
		eigen1L = sqrt(abs(dummyL(0).real()));//sqrt gives us the std of distribution
		eigen2L = sqrt(abs(dummyL(1).real()));
	
		averageGraphE.connection[edgeL].x = meanXL;
		averageGraphE.connection[edgeL].y = meanYL;
		if (abs(eigen1L) > abs(eigen2L))//take EVec1 as first PC. Scale with sqrt(EV).
		{
			dummyL = fla_matrixToVector(eigenVecL,0);
			averageGraphE.connection[edgeL].PC1[0] = dummyL(0).real();
			averageGraphE.connection[edgeL].PC1[1] = dummyL(1).real();
			dummyL = fla_matrixToVector(eigenVecL,1);
			averageGraphE.connection[edgeL].PC2[0] = dummyL(0).real();
			averageGraphE.connection[edgeL].PC2[1] = dummyL(1).real();
			averageGraphE.connection[edgeL].PC1[0] *= eigen1L;
			averageGraphE.connection[edgeL].PC1[1] *= eigen1L;
			averageGraphE.connection[edgeL].PC1length = eigen1L;
			averageGraphE.connection[edgeL].PC2[0] *= eigen2L;
			averageGraphE.connection[edgeL].PC2[1] *= eigen2L;
			averageGraphE.connection[edgeL].PC2length = eigen2L;
		}
		else
		{
			dummyL = fla_matrixToVector(eigenVecL,1);
			averageGraphE.connection[edgeL].PC1[0] = dummyL(0).real();
			averageGraphE.connection[edgeL].PC1[1] = dummyL(1).real();
			dummyL = fla_matrixToVector(eigenVecL,0);
			averageGraphE.connection[edgeL].PC2[0] = dummyL(0).real();
			averageGraphE.connection[edgeL].PC2[1] = dummyL(1).real();
			averageGraphE.connection[edgeL].PC1[0] *= eigen2L;
			averageGraphE.connection[edgeL].PC1[1] *= eigen2L;
			averageGraphE.connection[edgeL].PC1length = eigen2L;
			averageGraphE.connection[edgeL].PC2[0] *= eigen1L;
			averageGraphE.connection[edgeL].PC2[1] *= eigen1L;
			averageGraphE.connection[edgeL].PC2length = eigen1L;
		}
//		std::cout<<"here3"<<std::endl;	
//	  std::cout<<edgeL<<": x:"<<xL<< " meanX: "<<meanXL<<" y:"<<yL<< " meanY: "<<meanYL<<" eigen1: "<<eigen1L<<", eigen2: "<<eigen2L<<",\n PC1:"<<averageGraphE.connection[edgeL].PC1[0]<<","<<averageGraphE.connection[edgeL].PC1[1]<<", PC2:"<<averageGraphE.connection[edgeL].PC2[0]<<","<<averageGraphE.connection[edgeL].PC2[1]<<std::endl;		
	  if (eigen1L !=eigen1L)
	  	std::cout<<"NaN!!"<<std::endl;
	  if (std::isnan(eigen1L))
	  	std::cout<<"NaN2!!"<<std::endl;	  
	}
	//std::cout<<"Calculating finished"<<std::endl;	
	return true;
};

int AverageGraph_App::numberOfGraphs()
{
	if (currentGraphE.node.size()>0)//if not, we don't have a graph yet
	{	return graphsE.size()+1;}
	else
	{return graphsE.size();}
}

int AverageGraph_App::checkCoordinate(double xA, double yA)
{
  int indexL = 0;

  for(std::vector<Node>::const_iterator iterL = listOfNodesE.begin(); iterL != listOfNodesE.end(); ++iterL)
  {
    if((abs((*iterL).x - xA) < .01) && (abs((*iterL).y - yA) < .01))
    {
      return indexL;
    }
    ++indexL;
  }
  return -1;
};

void AverageGraph_App::newNode(double xA, double yA)
{
  Node tmpL;

  tmpL.x = xA;
  tmpL.y = yA;

  listOfNodesE.push_back(tmpL);
};

void AverageGraph_App::setNodeCoordinates(int indexA, double xA, double yA)
{
  listOfNodesE[indexA].x = xA;
  listOfNodesE[indexA].y = yA;
};


bool AverageGraph_App::init()
{
  return true;
};

bool AverageGraph_App::exit()
{
  return true;
};

void AverageGraph_App::fileFind(std::ifstream &fileA, std::string stringA)
{
  std::string stringL;

  fileA >> stringL;
  while(stringL != stringA)
  {
    fileA >> stringL;
  }
};

#endif
