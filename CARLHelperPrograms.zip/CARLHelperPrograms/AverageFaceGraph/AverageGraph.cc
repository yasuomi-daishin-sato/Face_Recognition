#include <Interface/AWLApplication.h>
#include <Interface/Application.h>
#include <Interface/MainWindow.h>

#include "AverageGraph_App.h"
#include "AverageGraph_GUI.h"

int main(int argc, char** argv)
{
  fin_AWLApplication appL(argc, argv);

  MainWindowPointer mainWindowL(new fin_MainWindow("Face Graph Averager ", "The main window", 0, 910, 200, 50));

  AverageGraph_App applicationL;

  fin_Application::setInstance(&applicationL);

  AverageGraph_GUI_Pointer windowControllerL(new AverageGraph_GUI(mainWindowL.pointer()));

  fin_Application::instance()->windowController(windowControllerL.pointer());

  return appL.exec();
};
