#ifndef DIALOG_H
#define DIALOG_H

#include <Interface/DependentWindow.h>
#include <Interface/MainWindow.h>
#include <Interface/AWLWindowPointer.h>
#include <Interface/AWLButtonPointer.h>
#include <Util/TemplatePointer.h>
#include <Interface/WidgetPairTemplate.h>
#include <Interface/AWLTextViewPointer.h>
#include<sstream>

#include "AverageGraph_App.h"
#include "AverageGraph_GUI.h"

class Dialog;

typedef fut_TemplatePointer<Dialog> DialogPointer;

class Dialog : public fin_DependentWindow
{
  friend class fut_TemplatePointer<Dialog>;
  friend class fut_TemplatePointer<const Dialog>;

  private:
    fin_AWLButtonPointer loadButtonE;
    fin_AWLButtonPointer loadAllButtonE;
    fin_WidgetPairTemplate<fin_AWLLabelPointer, fin_AWLTextViewPointer> numberGraphsTextE;
     fin_AWLButtonPointer clearButtonE;  
    fin_AWLButtonPointer saveButtonE;
    fin_AWLButtonPointer quitButtonE;  
      
    AverageGraph_App* application();

  public:
    Dialog(fin_DependentWindow* parentWindowPtrA);

    bool init();

    bool exit();//!this function is required
    
    void update();

    bool clickEvent(fin_AWLEventBase*);
    
    
};
#endif
