#ifndef AVERAGEGRAPH_APP_H
#define AVERAGEGRAPH_APP_H


//---------- includes ---------------------------------------------------

#include <Interface/Application.h>
#include <Image/ImagePointer.h>
#include <LinearAlgebra/Types.h>
#include <LinearAlgebra/Functions.h>
#include <LinearAlgebra/Convert.h>
struct Node
{
  double x;
  double y;
  double PC1[2];//because flavor vectors are too awkward
  double PC1length;
  double PC2[2];
  double PC2length;
};

struct Connection
{
  int connectorA;
  int connectorB;
  double x;
  double y;
  double PC1[2];
  double PC1length;
  double PC2[2];
  double PC2length;  
};

struct Tripel
{
  uint nodeA;
  uint nodeB;
  uint nodeC;
};

struct Graph
{
	Node CoM;//offset of center of mass of all nodes from image center
	std::vector<Node> node;
	std::vector<Connection> connection;
};

//---------- class definition -------------------------------------------

class AverageGraph_App : public fin_Application
{

//-----private variables-----//

  private:

    fim_ImagePointer imagePointerE;

    std::vector<Node> listOfNodesE;

    std::vector<Connection> listOfConnectionsE;

 		Graph currentGraphE;
 		
 		std::vector<Graph> graphsE;
 		
 		Graph averageGraphE;
    
    std::string imageFileNameE;



//-----private functions-----//

  private:

//---------- public functions -------------------------------------------

  public:

    AverageGraph_App();

    ~AverageGraph_App();

    bool loadImage(std::string nameA);

    bool loadGraph(std::string nameA);
       
    void clear();

    bool saveGraph(std::string nameA);
    
    bool calculateAverage();//update the average graph from graphsE

    bool isImageLoaded(){return !imagePointerE.empty();};

    fim_ImagePointer returnPointerToImage(){return imagePointerE;};

    int checkCoordinate(double xA, double yA);

    uint currentNumberOfNodes(){return currentGraphE.node.size();};
    uint currentNumberOfConnections(){return currentGraphE.connection.size();};

    uint averageNumberOfNodes(){return averageGraphE.node.size();};
    uint averageNumberOfConnections(){return averageGraphE.connection.size();};
    
    int numberOfGraphs();

    double currentXCoord(uint indexA){return ((currentGraphE.node.at(indexA))).x;};
    double currentYCoord(uint indexA){return ((currentGraphE.node.at(indexA))).y;};

    double currentConnectorACoordX(int indexA){return (currentGraphE.node[((currentGraphE.connection.at(indexA))).connectorA]).x;};
    double currentConnectorACoordY(int indexA){return (currentGraphE.node[((currentGraphE.connection.at(indexA))).connectorA]).y;};
    double currentConnectorBCoordX(int indexA){return (currentGraphE.node[((currentGraphE.connection.at(indexA))).connectorB]).x;};
    double currentConnectorBCoordY(int indexA){return (currentGraphE.node[((currentGraphE.connection.at(indexA))).connectorB]).y;};

    double averageXCoord(uint indexA){return ((averageGraphE.node.at(indexA))).x;};
    double averageYCoord(uint indexA){return ((averageGraphE.node.at(indexA))).y;};
    double averageXPC1(uint indexA){return ((averageGraphE.node.at(indexA))).PC1[0];};
    double averageYPC1(uint indexA){return ((averageGraphE.node.at(indexA))).PC1[1];};
    double averagePC1length(uint indexA){return ((averageGraphE.node.at(indexA))).PC1length;};
    double averageXPC2(uint indexA){return ((averageGraphE.node.at(indexA))).PC2[0];};
    double averageYPC2(uint indexA){return ((averageGraphE.node.at(indexA))).PC2[1];};
    double averagePC2length(uint indexA){return ((averageGraphE.node.at(indexA))).PC2length;};    
    

    double averageConnectorACoordX(int indexA){return (averageGraphE.node[((averageGraphE.connection.at(indexA))).connectorA]).x;};
    double averageConnectorACoordY(int indexA){return (averageGraphE.node[((averageGraphE.connection.at(indexA))).connectorA]).y;};
    double averageConnectorBCoordX(int indexA){return (averageGraphE.node[((averageGraphE.connection.at(indexA))).connectorB]).x;};
    double averageConnectorBCoordY(int indexA){return (averageGraphE.node[((averageGraphE.connection.at(indexA))).connectorB]).y;};
  
    Connection averageConnection(int indexA){return (averageGraphE.connection[indexA]);};
    	
    void newNode(double xA, double yA);//??noetig

    void setNodeCoordinates(int indexA, double xA, double yA);

//    void setAverageNodeCoordinates(int indexA, double xA, double yA,double PC1A,fla_RealVector PC2A);
     
     void fileFind(std::ifstream &fileA, std::string stringA);

    bool init();

    bool exit();
};
#endif
