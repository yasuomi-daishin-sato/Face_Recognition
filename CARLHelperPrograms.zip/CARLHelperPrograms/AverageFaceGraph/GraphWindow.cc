#ifndef GRAPHWINDOW_CC
#define GRAPHWINDOW_CC


//---------- includes ---------------------------------------------------

#include <Interface/AWLApplication.h>
#include <Interface/DrawListPointer.h>

#include "GraphWindow.h"


//---------- constructors ---------------------------------------------------

GraphWindow::GraphWindow(fin_DependentWindow* parentWindowPtrA, int graphTypeA)
: fin_DependentWindow(parentWindowPtrA, true, "Graph Window", "", 140, 0, 100, 100),
  canvasE(this, "Canvas", "Canvas")
{
	graphTypeE = graphTypeA;
  init();
};

bool GraphWindow::init()
{
  fin_DrawListPointer drawListL;

  drawListL->setVisibleRegion(0., 0., 1., 1.);
  drawListL->setPenStyle(1);
  canvasE->drawList(drawListL);
  drawCommandsE = 0;
  visibleE=false;
  resize(400,400);
  if (graphTypeE == 2)//only for average graph
    move(400, 0);
  return true;
};

bool GraphWindow::exit()
{
  return true;
};

void GraphWindow::update()
{
  if(visibleE)
  {
    uint sizeL;

    fin_DrawListPointer drawListL = canvasE->drawList();
    drawListL->removeLast(drawCommandsE);
    drawCommandsE = 0;

   	if (graphTypeE ==1)
   	{
      sizeL = application()->currentNumberOfConnections();

      for(uint i = 0; i < sizeL; ++i)
      {
        drawListL->setColor(0., 1., 1.);
        drawListL->line(application()->currentConnectorACoordX(i), application()->currentConnectorACoordY(i),
                        application()->currentConnectorBCoordX(i), application()->currentConnectorBCoordY(i));
        drawCommandsE += 2;
      }
    	sizeL = application()->currentNumberOfNodes();
   	}
   	else 
    {
      sizeL = application()->averageNumberOfConnections();
 	    double centerXL,centerYL;
 	    Connection connectionL;
      for(uint i = 0; i < sizeL; ++i)
      {
        drawListL->setColor(0., 1., 1.);
        drawListL->line(application()->averageConnectorACoordX(i), application()->averageConnectorACoordY(i),
                        application()->averageConnectorBCoordX(i), application()->averageConnectorBCoordY(i));
        drawCommandsE += 2;
        //now std stuff
        drawListL->setColor(1., 0., 1.);
        centerXL = (application()->averageConnectorACoordX(i) + application()->averageConnectorBCoordX(i))/2;
        centerYL = (application()->averageConnectorACoordY(i) + application()->averageConnectorBCoordY(i))/2;
        connectionL = application()->averageConnection(i);
  //      drawListL->circle(centerXL, centerYL, .0075, true);
//        std::cout<<connectionL.PC1[0]<<" and " <<connectionL.PC1[1]<<std::endl;
//here, draw the rhombi representing principal axes
        drawListL->line(centerXL + connectionL.PC1[0], centerYL + connectionL.PC1[1], centerXL + connectionL.PC2[0], centerYL + connectionL.PC2[1]);
        drawListL->line(centerXL + connectionL.PC2[0], centerYL + connectionL.PC2[1], centerXL - connectionL.PC1[0], centerYL - connectionL.PC1[1]);
        drawListL->line(centerXL - connectionL.PC1[0], centerYL - connectionL.PC1[1], centerXL - connectionL.PC2[0], centerYL - connectionL.PC2[1]);
        drawListL->line(centerXL - connectionL.PC2[0], centerYL - connectionL.PC2[1], centerXL + connectionL.PC1[0], centerYL + connectionL.PC1[1]);                           
        drawListL->setColor(0., 1., 1.);
        drawCommandsE += 7;
        
      }
    	sizeL = application()->averageNumberOfNodes();
   	}
   	
    drawListL->setColor(0., 0., 1.);
    drawCommandsE += 1;
    double xL,yL,PC1xL,PC2xL,PC1yL,PC2yL;
    for(int i = 0; i < sizeL; ++i)
    {

			if (graphTypeE ==1) {
        drawListL->circle(application()->currentXCoord(i), application()->currentYCoord(i), .0075, true);
			drawCommandsE += 1;
			}
      else {
      	 xL = application()->averageXCoord(i);
      	 yL = application()->averageYCoord(i);
         drawListL->circle(xL, yL, .0075, true);
         drawCommandsE += 1;
         drawListL->setColor(1., 0., 0.);
         PC1xL = application()->averageXPC1(i);
         PC2xL = application()->averageXPC2(i);
         PC1yL = application()->averageYPC1(i);
         PC2yL = application()->averageYPC2(i);
         drawListL->line(xL + PC1xL, yL + PC1yL, xL + PC2xL, yL + PC2yL);
         drawListL->line(xL + PC2xL, yL + PC2yL, xL - PC1xL, yL - PC1yL);
         drawListL->line(xL - PC1xL, yL - PC1yL, xL - PC2xL, yL - PC2yL);
         drawListL->line(xL - PC2xL, yL - PC2yL, xL + PC1xL, yL + PC1yL);                           
        //ellipse cannot be rotated
        // drawListL->ellipse(xL, yL,application()->averagePC1length(i),application()->averagePC2length(i),false, atan(application()->averageYPC1(i)/application()->averageXPC1(i)),M_PI);
	       drawListL->setColor(0., 0., 1.);
	       drawCommandsE += 6;
      }
    }
 

/*    if((stepL == "setNodes") && (pickedUpE != -1))
    {
      drawListL->setColor(1., 0., 0.);
      drawListL->circle(pickedUpCoordsXE, pickedUpCoordsYE, .0075, true);
      drawCommandsE += 2;
    }*/

    canvasE->drawList(drawListL, true);
    show();
  }
  else
  {
    hide();
  }


};

bool GraphWindow::setImage()
{
  imagePointerE = application()->returnPointerToImage();

  if(!imagePointerE.empty())
  {
    fin_DrawListPointer drawListL;

    imageSizeXE = imagePointerE->xResolution();
    imageSizeYE = imagePointerE->yResolution();

    drawListL->image(imagePointerE, 0., 0., 1., 1.);
    resize(imageSizeXE, imageSizeYE);
    canvasE->drawList(drawListL);
  }
  drawCommandsE = 0;

  return true;
};


AverageGraph_App* GraphWindow::application()
{
  return static_cast<AverageGraph_App*>(fin_Application::instance());
};

#endif
