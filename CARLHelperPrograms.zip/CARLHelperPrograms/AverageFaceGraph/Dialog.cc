#ifndef DIALOG_CC
#define DIALOG_CC


//---------- includes ---------------------------------------------------

#include <Interface/AWLApplication.h>
#include "Dialog.h"

#define Y_POS 50
#define X_SIZE 150

//---------- constructors ---------------------------------------------------

Dialog::Dialog(fin_DependentWindow* parentWindowPtrA)
: fin_DependentWindow(parentWindowPtrA, true, "Dialog", "", 0, 0, 120, 4*30),
loadButtonE(this, "Load","Load Face Graph"),
loadAllButtonE(this, "Load All","Load all Face Graphs in current directory"),
numberGraphsTextE(this, "No. Graphs", "Number of Loaded Graphs"),
clearButtonE(this, "Clear","Clear all Face Graphs and Average Face"),
saveButtonE(this, "Save","Save Average Face Graph"),
quitButtonE(this, "Quit","Quit application")
{
  init();

numberGraphsTextE.secondComponent()->clear();
loadButtonE->enable(true);
saveButtonE->enable(false);
clearButtonE->enable(false);
quitButtonE->enable(true);
update();
};

bool Dialog::init()
{
  move(0, Y_POS);
  resize(X_SIZE,150);
  show();
  notify();


  return true;
};

bool Dialog::exit()
{
 return true;
};


bool Dialog::clickEvent(fin_AWLEventBase* widgetA)
{
 if(widgetA == loadButtonE.pointer())
  {
		if (AverageGraph_GUI::Instance->loadGraph())
		{
			saveButtonE->enable(true);
			clearButtonE->enable(true);
		  return true;  
		}
		else return false;
  }
 if(widgetA == loadAllButtonE.pointer())
  {
		if (AverageGraph_GUI::Instance->loadAllGraph())
		{
			saveButtonE->enable(true);
			clearButtonE->enable(true);
		  return true;  
		}
		else return false;
  }
if(widgetA == saveButtonE.pointer())
  {
    AverageGraph_GUI::Instance->saveGraph();
    return true;
  }
 if(widgetA == quitButtonE.pointer())
  {
    hide();
    AverageGraph_GUI::Instance->quit();
  }
  if(widgetA == clearButtonE.pointer())
  {
    AverageGraph_GUI::Instance->clear();
    saveButtonE->enable(false);
    clearButtonE->enable(false);
  }
   
  return false;	
};

void Dialog::update()
{
	numberGraphsTextE.secondComponent()->clear();
	std::stringstream streamL;
	streamL << application()->numberOfGraphs();
	numberGraphsTextE.secondComponent()->append(streamL.str());
	//numberGraphsTextE.secondComponent()->append("test");
};

AverageGraph_App* Dialog::application()
{
  return static_cast<AverageGraph_App*>(fin_Application::instance());
};

#endif
