#ifndef AVERAGEGRAPH_GUI_CC
#define AVERAGEGRAPH_GUI_CC

#include <Interface/AWLApplication.h>
#include <Interface/AWLFileDialog.h>
#include </usr/include/sys/types.h>
#include </usr/include/sys/param.h>
#include "AverageGraph_GUI.h"

AverageGraph_GUI* AverageGraph_GUI::Instance = 0;

AverageGraph_GUI::AverageGraph_GUI(fin_MainWindow* mainWindowPtrA)
: fin_WindowController(mainWindowPtrA)
{
  Instance = this;

  dialogPtrE = new Dialog(mainWindow());
  mainWindow()->addWindow(dialogPtrE);

  graphWindowPtrE = new GraphWindow(mainWindow(), 1);
  averageGraphWindowPtrE = new GraphWindow(mainWindow(), 2);
  mainWindow()->addWindow(graphWindowPtrE);
	mainWindow()->addWindow(averageGraphWindowPtrE);

  recentGraphDirectoryE = "";
};

AverageGraph_GUI::~AverageGraph_GUI()
{
  //here you may implement your own garbage collection
};

bool AverageGraph_GUI::loadGraph()
{
  std::string fileNameL = fin_AWLFileDialog::fileName(recentGraphDirectoryE, "*.*");

  if(fileNameL != "")
  {
  		
  	recentGraphDirectoryE = fileNameL.substr(0, fileNameL.rfind("/"));  	 	

    if(application()->loadGraph(fileNameL))
    {
      graphWindowPtrE->setImage();
//			averageGraphWindowPtrE->setImage();//this can be switched off if preferred
			graphWindowPtrE->visible(true);
			averageGraphWindowPtrE->visible(true);
      notify();
      return true;
    }    
  }
  return false;
};

bool AverageGraph_GUI::loadAllGraph()
{
	//just to get teh directory
  std::string fileNameL = fin_AWLFileDialog::fileName(recentGraphDirectoryE, "*.*");

  if(fileNameL != "")
  {
  		
  	recentGraphDirectoryE = fileNameL.substr(0, fileNameL.rfind("/"));
  	
	 	struct dirent **namelist;
	 	int countL = scandir(recentGraphDirectoryE.c_str(), &namelist, 0,0);
		std::cout<<"files in "<<recentGraphDirectoryE.c_str()<<" : "<<countL<<std::endl;
	  std::string fileL;
  	for (int i = 0 ; i< countL; ++i)
  	{
  		fileL=namelist[i]->d_name;
 		if (((fileL != ".") && (fileL != ".."))&&((fileL.find(".") != std::string::npos) &&(fileL.rfind("raph")==(fileL.size()-4))))//make somewhat sure we have a graph file
  		{
  			fileNameL = recentGraphDirectoryE + "/" + namelist[i]->d_name;
		  	std::cout<<fileNameL<<std::endl;
 		    application()->loadGraph(fileNameL);
  		}
  	}
  	 
        graphWindowPtrE->setImage();
//	averageGraphWindowPtrE->setImage();//this can be switched off if preferred
		graphWindowPtrE->visible(true);
		averageGraphWindowPtrE->visible(true);
    notify();   
    return true; 
  }
  
  return false;
};

void AverageGraph_GUI::clear()
{
	application()->clear();
	graphWindowPtrE->visible(false);
	averageGraphWindowPtrE->visible(false);
  notify();
};

bool AverageGraph_GUI::saveGraph()
{
  std::string fileNameL = fin_AWLFileDialog::fileName(recentGraphDirectoryE, "*.*");

  if(fileNameL != "")
  {
    recentGraphDirectoryE = fileNameL.substr(0, fileNameL.rfind("/"));

    if(application()->saveGraph(fileNameL))
    {
      return true;
    }

  }
  return false;
};

void AverageGraph_GUI::quit()
{
  if(mainWindow()->exit() && fin_Application::instance()->exit())
  {
    fin_AWL::quit();
  }
};

AverageGraph_App* AverageGraph_GUI::application()
{
  return static_cast<AverageGraph_App*>(fin_Application::instance());
};

#endif
