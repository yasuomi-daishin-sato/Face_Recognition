#ifndef GRAPHWINDOW_H
#define GRAPHWINDOW_H

#include <Interface/AWLCanvasPointer.h>
#include <Interface/DependentWindow.h>
#include <Interface/MainWindow.h>
#include <Interface/AWLWindowPointer.h>
#include <Interface/AWLButtonPointer.h>
#include <Image/ImagePointer.h>
#include <Util/TemplatePointer.h>

#include "AverageGraph_App.h"
#include "AverageGraph_GUI.h"

class GraphWindow;

typedef fut_TemplatePointer<GraphWindow> GraphWindowPointer;

class GraphWindow : public fin_DependentWindow
{
  friend class fut_TemplatePointer<GraphWindow>;
  friend class fut_TemplatePointer<const GraphWindow>;

  private:

    AverageGraph_App* application();

    fin_AWLCanvasPointer canvasE;

    fim_ImagePointer imagePointerE;
    
    bool visibleE;//!flag defining whether graph is visible
    int graphTypeE;//!1 for normal graph, 2 for average graph

    int imageSizeXE;
    int imageSizeYE;
    int drawCommandsE;
    int connector1E;

//    double pickedUpCoordsXE;
  //  double pickedUpCoordsYE;
    //int pickedUpE;

  public:
    GraphWindow(fin_DependentWindow* parentWindowPtrA, int graphTypeA);

    bool setImage();
    
    bool init();

    bool exit();

    void update();
    
    void visible(bool visibleA){visibleE = visibleA;};
};
#endif
