#ifndef AVERAGEGRAPH_GUI_H
#define AVERAGEGRAPH_GUI_H

#include <Util/TemplatePointer.h>
#include <Interface/WindowController.h>
#include <Interface/MainWindow.h>

#include "AverageGraph_App.h"
#include "Dialog.h"
#include "GraphWindow.h"

class Dialog;
class GraphWindow;
class AverageGraph_GUI;

typedef fut_TemplatePointer<AverageGraph_GUI> AverageGraph_GUI_Pointer;

class AverageGraph_GUI : public fin_WindowController
{
  friend class fut_TemplatePointer<AverageGraph_GUI>;
  friend class fut_TemplatePointer<const AverageGraph_GUI>;

	private:
    Dialog* dialogPtrE;
    GraphWindow* graphWindowPtrE;
		GraphWindow* averageGraphWindowPtrE;
    std::string recentGraphDirectoryE;
   

	public:
    static AverageGraph_GUI *Instance;

    AverageGraph_GUI(fin_MainWindow* mainWindowPtrA);

    virtual ~AverageGraph_GUI();

    bool loadGraph();
    
    bool loadAllGraph();
    
    void clear();

    bool saveGraph();

    void quit();

    AverageGraph_App* application();
};
#endif
